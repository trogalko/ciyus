<div id="top">
    <div class="top">
        <table width="100%" border="0" cellpadding="0" cellspacing="0">
            <tr>
                <td height="105" align="right" valign="top"><a href="#">
                    <div style="float:left; width:250px; height:100px;"></div></a>
                    <div style="float:left; margin-top:75px; margin-left:20px; color:#FFFFFF;"><?php echo $arrID['Nama'] ?></div>
                    <div style="float:right; padding: 10px; ;">&nbsp;</div>
                </td>
            </tr>
            <tr>
                <td height="45" valign="bottom">&nbsp;</td>
            </tr>
        </table>
    </div>
</div>