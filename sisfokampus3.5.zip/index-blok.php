<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
  <head>
  <meta http-equiv="content-type" content="text/html; charset=windows-1250">
  <meta name="generator" content="PSPad editor, www.pspad.com">
  <title></title>
  </head>
  <body>
  <center><h1>Server PTI Sedang Di-<i>disable</i></h1>
  <hr>
  <p>Saat ini Server PTI sedang tidak dapat diakses karena sedang dialihkan.</p>
  <hr>
  <p>Universitas Kristen Krida Wacana - Sisfo Kampus</p>
  
  </body>
</html>
