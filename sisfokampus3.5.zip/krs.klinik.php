<?php
// Author: Emanuel Setio Dewo
// 11 April 2006

// *** Functions ***


// *** Parameters ***


// *** Main ***
TampilkanJudul("Pra KRS Klinik");
?>