<?php
// Parameter untuk PMB Online

$_INSTITUTION = "SISFO KAMPUS";
?>