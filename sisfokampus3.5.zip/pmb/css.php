<style type="text/css">
a { text-decoration: none; }
a:link
  { color: darkred; }
a:visited {color: darkred; }
a:active  {color: darkred; }
a:hover   {
  color: white; 
  background-color: #00CCCC;
  font-weight: normal;
}
BODY {
  color: black;
  margin: 0 5 0 5;
  padding: 0 0 0 0;
  width: auto;
  font-family : tahoma, helvetica;
  font-weight : normal;
  font-size: 10pt;
}
img {
  border: 0;
}
#td a:hover {
  background: maroon;
  color: yellow;
}
.menu {
  font-family : verdana, arial, helvetica, sans-serif;
  font-size : 10pt;
}
.menuitem {
  border : 1px solid silver;
  padding: 4px;
}
.menuaktif {
  border : 1px solid silver;
  background : #CCFFCC;
  padding: 4px;
}
.JudulBesar {
  display: inline;
  font-size: 3em;
  font-family: Times;
  color: black;
}
.Judul {
  font-size: 2em;
  font-family: Times;
  color: gray;
}
.NamaLogin {
  float: right;
  right: 0;
  font-size: 0.8em;
  color: gray;
}
.MenuDirectory {
  font-size: 0.8em;
  color: gray;
}
.box {
  font-size: 10pt;
  border: 1px solid silver;
}
.bsc {
  font-size: 10pt;
}
.ttl {
  border-bottom : 1px solid gray;
  background : #CEECEE;
}
.inp {
  font-weight: bold;
  text-align: right;
  background: #DEDEDE;
  border-bottom: 1px solid silver;
}
.inp1 {
  background : #CCFFDD;
  border-bottom: 1px solid silver;
}
.inp2 {
  background : #CCFFCC;
}
.nac {
  background : silver;
  color : gray;
}
.hdr {
  background : white;
  border-top: 2px solid silver;
  border-bottom: 1px solid silver;
  font-weight: bold;
}
.ul {
  border-bottom: 1px solid #ddd;
}
.kolkir {
  border-right: 1px solid silver;
  padding: 0 4px 0 0;
}
.kolkan {
  padding: 0 0 0 4px;
}
.cnaY {
  background: silver;
  color: gray;
}
.cnaN {
  background: white;
  color: black;
  border-bottom: 1px solid silver;
}
.cnnY {
  background: yellow;
  color: black;
  border-bottom: 1px solid silver;
}
.cnnN {
  background: white;
  color: black;
  border-bottom: 1px solid silver;
}
.wrn {
  background: red;
  color: yellow;
}
.kiri {
  width: 150;
  float: left;
}
.submenu {
  font-size: 0.8em;
  clear: both;
  display: block;
}
.submenu ul, .submenu li {
  display: inline;
  list-style-type: none;
  list-style-image: none;
  border: 1px solid silver;
  padding: 0px;
  line-height: 1em;
}

</style>
