<?php
// Author: Emanuel Setio Dewo
// 26 May 2006
// http://www.sisfokampus.net


?>

<p class="header">Anjungan Informasi Mahasiswa</p>
