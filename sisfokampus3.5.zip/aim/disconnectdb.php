<?php
  mysql_close($con);
?>