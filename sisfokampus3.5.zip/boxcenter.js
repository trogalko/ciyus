$(document).ready(function(){
    $(".isi").wrap("<center></center>");
    $("th.ttl").attr("nowrap", true);
});
