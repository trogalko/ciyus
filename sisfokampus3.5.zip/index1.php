<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
  <head>
  <meta http-equiv="content-type" content="text/html; charset=windows-1250">
  <meta name="generator" content="PSPad editor, www.pspad.com">
  <title></title>
  </head>
  <body>
  <center><h1>Sedang Ada Perbaikan Data</h1>
  <hr>
  <p>Saat ini Sisfo Kampus tidak dapat diakses karena sedang ada perbaikan data.</p>
  
  </body>
</html>
