<?php
//function Preview();
include "dwo.lib.php";
$nmf = $_REQUEST['nmf'];

TampilkanFileDWOPRN($nmf);
?>