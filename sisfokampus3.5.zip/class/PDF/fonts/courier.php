<?php
/**
 * @package File_PDF
 */
for ($i = 0; $i <= 255; $i++) {
    $font_widths['courier'][chr($i)] = 600;
}
$font_widths['courierB'] = $font_widths['courier'];
$font_widths['courierI'] = $font_widths['courier'];
$font_widths['courierBI'] = $font_widths['courier'];
