<?php
// Author: Emanuel setio Dewo
// 29 Juli 2006
// www.sisfokampus.net
  

// *** Functions ***


// *** Parameters ***


// *** Main ***
// tampilkan judul
?>
<h1>Utility Untuk Membuat file PHP Berantakan</h1>
<hr>
<p>Masukkan nama file teks yang akan dibuat berantakan:<br />
<form action='?' method=POST>
<input type=file size=60>
</form>
</p>

<?php
?>